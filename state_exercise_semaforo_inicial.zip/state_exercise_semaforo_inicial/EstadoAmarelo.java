public class EstadoAmarelo implements EstadoSemaforo {
    @Override
    public void mostrarSinal() {
        System.out.println("AMARELO - ATENÇÃO");
    }

    @Override
    public void transicionar(Semaforo semaforo) {
        semaforo.setEstado(new EstadoVermelho());
    }

    @Override
    public int getTempo() {
        return 5;
    }
}