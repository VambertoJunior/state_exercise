public class EstadoVermelho implements EstadoSemaforo {
    @Override
    public void mostrarSinal() {
        System.out.println("VERMELHO - PARE");
    }

    @Override
    public void transicionar(Semaforo semaforo) {
        semaforo.setEstado(new EstadoVerde());
    }

    @Override
    public int getTempo() {
        return 15;
    }
}