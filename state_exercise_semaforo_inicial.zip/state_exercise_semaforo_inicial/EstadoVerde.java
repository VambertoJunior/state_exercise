public class EstadoVerde implements EstadoSemaforo {
    @Override
    public void mostrarSinal() {
        System.out.println("VERDE - SIGA");
    }

    @Override
    public void transicionar(Semaforo semaforo) {
        semaforo.setEstado(new EstadoAmarelo());
    }

    @Override
    public int getTempo() {
        return 25;
    }
}